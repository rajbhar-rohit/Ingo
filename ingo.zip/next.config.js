module.exports = {
    images: {
      domains: ['logos.textgiraffe.com'],
    },
  }