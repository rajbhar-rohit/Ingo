// API Key - https://developers.google.com/custom-search/v1/using_rest
export const API_KEY = 'AIzaSyBgH8QFsSCeaUKtnJSnEXh5G43x8mY9SYY'

// Context Key - https://cse.google.com/cse/create/new
export const CONTEXT_KEY = 'b09e7fbc6e1e5a051'